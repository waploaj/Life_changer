package android.support.v4.app;

import android.app.Activity;
import android.net.Uri;

class ActivityCompat22
{
  public static Uri getReferrer(Activity paramActivity)
  {
    return paramActivity.getReferrer();
  }
}


/* Location:              F:\reverse enginner\dex\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\ActivityCompat22.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */