package android.support.v4.app;

class NotificationCompatApi23
{
  public static final String CATEGORY_REMINDER = "reminder";
}


/* Location:              F:\reverse enginner\dex\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\app\NotificationCompatApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */