package android.support.v4.content;

import android.content.Intent;

class IntentCompatIcsMr1
{
  public static Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return Intent.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:              F:\reverse enginner\dex\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\content\IntentCompatIcsMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */