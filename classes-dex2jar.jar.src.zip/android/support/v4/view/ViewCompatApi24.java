package android.support.v4.view;

import android.view.PointerIcon;
import android.view.View;

class ViewCompatApi24
{
  public static void setPointerIcon(View paramView, Object paramObject)
  {
    paramView.setPointerIcon((PointerIcon)paramObject);
  }
}


/* Location:              F:\reverse enginner\dex\dex2jar-2.0\classes-dex2jar.jar!\android\support\v4\view\ViewCompatApi24.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */